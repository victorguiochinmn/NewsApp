//
//  SavedViewController.swift
//  final
//
//  Created by UDLAP21 on 2/21/19.
//  Copyright © 2019 DevLabs. All rights reserved.
//

import UIKit
import SwiftyJSON

class SavedViewController: UITableViewController {
    
    override func viewDidLoad() {
        getSaved { (success) in
            DispatchQueue.main.async {
                super.viewDidLoad()
                self.initializeView()
            }
        }
    }
    
    private func initializeView() {
        tableView.rowHeight = 65
        tableView.estimatedRowHeight = 65
        tableView.delegate=self
        tableView.dataSource = self
        tableView.reloadData()
    }
    
    func getSaved(_ completion:@escaping (Bool)->()){
        var baseURL = URLComponents(string: "https://newsapi-victorguiochinmn.c9users.io/articles")
        baseURL?.queryItems = [URLQueryItem(name: "username", value: String(describing: Model.ID))]
        let urlRequest = URLRequest(url: baseURL?.url as! URL)
        let session = URLSession.shared
        session.dataTask(with: urlRequest) {
            (data,response,error) in
                guard error == nil else { completion(false); return}
                guard let data = data else { return}
                let jsonResponse = JSON(data as Any)
                let articles = [Noticia]()
                if let articles = jsonResponse["articles"].arrayObject as? [[String:Any]] {
                    for filter in articles {
                        let newGuardado = Noticia(unTitulo: filter["title"] as! String, unaFuente: filter["source"] as? String ?? "Unknown", unaURL: filter["url"] as! String)
                        Model.addSaved(newGuardado)
                    }
            }
            completion(true)
        }.resume()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        switch segue.identifier {
        case "toWeb"?:
            if let row = tableView.indexPathForSelectedRow?.row {
                Model.indiceGuardado = row
            }
        default:
            preconditionFailure("Unexpected segue identifier.")
        }
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Model.saved.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell : ItemCell
        var item : Noticia
        item = Model.saved[indexPath.row]
        cell = tableView.dequeueReusableCell(withIdentifier: "cellSaved", for: indexPath) as! ItemCell
        cell.tituloLabel3.text = item.titulo
        cell.autorLabel.text = item.periodico
        return cell
    }
    
    override func viewWillAppear(_ animated: Bool) {
        tableView.reloadData()
        super.viewWillAppear(true)
    }
}
