//
//  Login.swift
//  final
//
//  Created by UDLAP21 on 3/27/19.
//  Copyright © 2019 DevLabs. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON
import SwiftyPlistManager

class Login: UIViewController {
    var pass:Bool = false
    @IBOutlet weak var usernameTextField: UITextField!
    @IBOutlet weak var passworddTextField: UITextField!
    @IBOutlet weak var errorLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        SwiftyPlistManager.shared.start(plistNames: ["dataPlist"], logging: true)
    }
    
    @IBAction func login(_ sender: Any) {
        check { (success) in
            DispatchQueue.main.async {
                self.goToNews()
            }
        }
    }
    
    func goToNews() {
        if pass {
            self.performSegue(withIdentifier: "login2News", sender: self)
        } else {
            errorLabel.text = "Wrong username or password"
        }
    }
    
    func check(_ completion:@escaping (Bool)->()) {
        let username: String = usernameTextField.text!
        let password: String = passworddTextField.text!
        var baseURL = URLComponents(string: "https://newsapi-victorguiochinmn.c9users.io/users")
        baseURL?.queryItems = [URLQueryItem(name: "username", value: username), URLQueryItem(name: "password", value: password)]
        let urlRequest = URLRequest(url: baseURL?.url as! URL)
        let session = URLSession.shared
        session.dataTask(with: urlRequest) {
            (data,response,error) in
            guard error == nil else { completion(false); return}
            guard let data = data else { return}
            do {
                if let convertedJsonIntoDict = try JSONSerialization.jsonObject(with: data, options: []) as? NSDictionary {
                    if convertedJsonIntoDict["status"] as! String == "OK" {
                        let id: String = convertedJsonIntoDict["_id"] as! String
                        SwiftyPlistManager.shared.save(id, forKey: "ID", toPlistWithName: "dataPlist") { (err) in
                          if err == nil {
                            print("Value added")
                          }
                        }
                        self.pass = true
                        completion(true)
                    }
                }
            } catch let error as NSError {
                print(error.localizedDescription)
            }
        }.resume()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
}
