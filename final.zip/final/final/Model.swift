//
//  Model.swift
//  final
//
//  Created by UDLAP21 on 3/27/19.
//  Copyright © 2019 DevLabs. All rights reserved.
//

import Foundation
import SwiftyPlistManager

public class Model {
    static var news: Array<Noticia> = []
    static var filters: Array<Filter> = []
    static var filterNews: Array<Noticia> = []
    static var saved: Array<Noticia> = []
    static var indiceDelActual = 0
    static var indicefiltros = 0
    static var indiceFiltroNoticia = 0
    static var indiceGuardado = 0
    static var ID = ""
    
    static func addItem(_ item: Noticia){
        news.insert(item, at: 0)
    }
    
    static func addFilter(_ item: Filter){
        filters.insert(item, at: 0)
    }
    
    static func addFilterNew(_ item: Noticia){
        filterNews.insert(item, at: 0)
    }
    
    static func addSaved(_ item: Noticia){
        saved.insert(item, at: 0)
    }
    
    static func removeItem(_ item: Noticia) {
        if let index = news.index(of:item) {
            news.remove(at:index)
        }
    }
    
    static func removeFilter(_ item: Filter) {
        if let index = filters.index(of:item) {
            filters.remove(at:index)
        }
    }
    
    static func removeFilterNew(_ item: Noticia) {
        if let index = filterNews.index(of:item) {
            filterNews.remove(at:index)
        }
    }
    
    static func removeSaved(_ item: Noticia) {
        if let index = saved.index(of:item) {
            saved.remove(at:index)
        }
    }
    
    static func moveItem(fromIndex: Int, totIndex: Int) {
        var movedItem: Noticia
        if fromIndex != totIndex {
            movedItem = news[fromIndex]
            news.remove(at: fromIndex)
            news.insert(movedItem, at: totIndex)
        }
    }
    
    static func initialize() {
        SwiftyPlistManager.shared.getValue(for: "ID", fromPlistWithName: "dataPlist") { (result,err) in
            if err == nil {
                self.ID = result as! String
            }
        }
    }
    
}
