//
//  FilterNews.swift
//  final
//
//  Created by UDLAP21 on 5/19/19.
//  Copyright © 2019 DevLabs. All rights reserved.
//

import Foundation
import UIKit
import SwiftyJSON

class FilterNews: UITableViewController {
    
    override func viewDidLoad() {
        getNews { (success) in
            DispatchQueue.main.async {
                super.viewDidLoad()
                self.initializeView()
                self.tableView.reloadData()
            }
        }
    }
    
    private func initializeView() {
        tableView.rowHeight = 65
        tableView.estimatedRowHeight = 65
    }
    
    override func viewWillAppear(_ animated: Bool) {
        getNews { (success) in
            DispatchQueue.main.async {
                super.viewWillAppear(true)
                self.tableView.reloadData()
            }
        }
    }
    
    func getNews(_ completion:@escaping (Bool)->()){
        var baseURL = URLComponents(string: "https://newsapi-victorguiochinmn.c9users.io/yourNewsHeadLines")
        baseURL?.queryItems = [URLQueryItem(name: "sources", value: Model.filters[Model.indicefiltros].parametros)]
        let urlRequest = URLRequest(url: baseURL?.url as! URL)
        let session = URLSession.shared
        session.dataTask(with: urlRequest) {
            (data,response,error) in
            guard error == nil else { completion(false); return}
            guard let data = data else { return}
            let response = JSON(data as Any)
            if let articles = response["articles"].arrayObject as? [[String:AnyObject]] {
                for article in articles{
                    let item = Noticia(unTitulo: article["title"] as? String ?? "Unknown", unaFuente: article["author"] as? String ?? "Unknown", unaURL: article["url"] as? String ?? "google.com")
                    Model.addFilterNew(item)
                }
            }
            completion(true)
        }.resume()
    }
    
    @IBAction func getBack(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        switch segue.identifier {
        case "showFilterNew"?:
            if let row = tableView.indexPathForSelectedRow?.row {
                Model.indiceFiltroNoticia = row
            }
        default:
            preconditionFailure("Unexpected segue identifier.")
        }
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Model.filterNews.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell : ItemCell
        var item : Noticia
        item = Model.filterNews[indexPath.row]
        cell = tableView.dequeueReusableCell(withIdentifier: "cellFilterNews", for: indexPath) as! ItemCell
        cell.tituloLabel2.text = item.titulo
        cell.fuenteLabel.text = item.periodico
        return cell
    }
}

