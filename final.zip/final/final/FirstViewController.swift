//
//  FirstViewController.swift
//  final
//
//  Created by UDLAP21 on 2/21/19.
//  Copyright © 2019 DevLabs. All rights reserved.
//

import UIKit
import SwiftyJSON
import SwiftyPlistManager

class FirstViewController: UITableViewController {
    @IBOutlet var tableview: UITableView! {
        didSet {
            tableview.dataSource = self
            tableview.delegate = self
        }
    }
    
    override func viewDidLoad() {
        getNews { (success) in
            DispatchQueue.main.async {
                Model.initialize()
                super.viewDidLoad()
                self.initializeView()
                self.tableview.reloadData()
            }
        }
    }
    
    private func initializeView() {
        tableView.rowHeight = 65
        tableView.estimatedRowHeight = 65
    }
    
    override func viewWillAppear(_ animated: Bool) {
        getNews { (success) in
            DispatchQueue.main.async {
                super.viewWillAppear(true)
                self.tableview.reloadData()
            }
        }
    }
    
    func getNews(_ completion:@escaping (Bool)->()){
       let scriptUrl = "https://newsapi-victorguiochinmn.c9users.io/world"
        let myUrl = NSURL(string: scriptUrl);
        let request = NSMutableURLRequest(url:myUrl! as URL);
        request.httpMethod = "GET"
        let task = URLSession.shared.dataTask(with: request as URLRequest) {
            data, response, error in
            if error != nil {
                print("error= \(String(describing: error))")
                completion(false)
                return
            }
            let response = JSON(data as Any)
            if let articles = response["articles"].arrayObject as? [[String:AnyObject]] {
                for article in articles{
                    let item = Noticia(unTitulo: article["title"] as? String ?? "Unknown", unaFuente: article["author"] as? String ?? "Unknown", unaURL: article["url"] as? String ?? "google.com")
                    Model.addItem(item)
                }
            }
            completion(true)
        }
        task.resume()
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        switch segue.identifier {
        case "showItem"?:
            if let row = tableView.indexPathForSelectedRow?.row {
                Model.indiceDelActual = row
            }
        default:
            preconditionFailure("Unexpected segue identifier.")
         }
    }
    
    override func tableView(_ tableView: UITableView, moveRowAt sourceIndexPath: IndexPath, to destinationIndexPath: IndexPath){
        Model.moveItem(fromIndex: sourceIndexPath.row, totIndex: destinationIndexPath.row)
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int { return Model.news.count }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            var cell : ItemCell
            var item : Noticia
            item = Model.news[indexPath.row]
            cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! ItemCell
            cell.tituloLabel.text = item.titulo
            cell.periodicoLabel.text = item.periodico
            return cell
    }
}

