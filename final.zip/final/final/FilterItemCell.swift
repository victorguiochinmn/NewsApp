//
//  FilterItemCell.swift
//  final
//
//  Created by UDLAP21 on 3/27/19.
//  Copyright © 2019 DevLabs. All rights reserved.
//

import UIKit

class FilterItemCell : UITableViewCell{
    
    @IBOutlet weak var nombreLabel: UILabel!
    @IBOutlet weak var tituloLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        //filtroLabel.adjustsFontForContentSizeCategory = true
    }
    
}
