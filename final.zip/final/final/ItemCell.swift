//
//  ItemCell.swift
//  final
//
//  Created by UDLAP21 on 3/27/19.
//  Copyright © 2019 DevLabs. All rights reserved.
//

import UIKit

class ItemCell : UITableViewCell{
    //FirstView
    @IBOutlet weak var tituloLabel: UILabel!
    @IBOutlet weak var periodicoLabel: UILabel!
    //FilterNews
    @IBOutlet weak var tituloLabel2: UILabel!
    @IBOutlet weak var fuenteLabel: UILabel!
    //Saved
    @IBOutlet weak var tituloLabel3: UILabel!
    @IBOutlet weak var autorLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
//        tituloLabel.adjustsFontForContentSizeCategory = true
  //      periodicoLabel.adjustsFontForContentSizeCategory = true
    }
    
}
