//
//  FilterConf.swift
//  final
//
//  Created by UDLAP21 on 3/27/19.
//  Copyright © 2019 DevLabs. All rights reserved.
//

import UIKit

class FilterConf: UIViewController {
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var descriptionTextView: UITextView!
    @IBOutlet weak var nameTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        check()
    }
    
    func updateDescription() {
        nameTextField.text = Model.filters[Model.indicefiltros].nombre
        descriptionTextView.text = Model.filters[Model.indicefiltros].parametros
    }
    
    @IBAction func getBack(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func guardar(_ sender: Any) {
        let item = Filter(unNombre: nameTextField.text!, param: descriptionTextView.text)
        if Model.indicefiltros == -1 {
            guardarServidor { (success) in
                DispatchQueue.main.async {
                    Model.addFilter(item)
                    self.dismiss(animated: true, completion: nil)
                }
            }
        } else {
            actualizarServidor { (success) in
                DispatchQueue.main.async {
                    self.dismiss(animated: true, completion: nil)
                }
            }
        }
    }
    
    func guardarServidor(_ completion:@escaping (Bool)->()){
        let nombre:String = nameTextField.text!
        let sources:String = descriptionTextView.text!
        var baseURL = URLComponents(string: "https://newsapi-victorguiochinmn.c9users.io/addFilter")
        baseURL?.queryItems = [URLQueryItem(name: "username", value: String(describing: Model.ID)), URLQueryItem(name: "name", value: nombre), URLQueryItem(name: "sources", value: sources)]
        let urlRequest = URLRequest(url: baseURL?.url as! URL)
        let session = URLSession.shared
        session.dataTask(with: urlRequest) {
            (data,response,error) in
            guard error == nil else { completion(false); return}
            guard let data = data else { return}
            do {
                if let convertedJsonIntoDict = try JSONSerialization.jsonObject(with: data, options: []) as? NSDictionary {
                    if convertedJsonIntoDict["status"] as! String == "OK" {
                        completion(true)
                    }
                }
            } catch let error as NSError {
                print(error.localizedDescription)
            }
        }.resume()
    }
    
    func actualizarServidor(_ completion:@escaping (Bool)->()){
        let nombre:String = nameTextField.text!
        let sources:String = descriptionTextView.text!
        var baseURL = URLComponents(string: "https://newsapi-victorguiochinmn.c9users.io/updateFilter")
        baseURL?.queryItems = [URLQueryItem(name: "username", value: String(describing: Model.ID)), URLQueryItem(name: "name", value: nombre), URLQueryItem(name: "sources", value: sources)]
        let urlRequest = URLRequest(url: baseURL?.url as! URL)
        let session = URLSession.shared
        session.dataTask(with: urlRequest) {
            (data,response,error) in
            guard error == nil else { completion(false); return}
            guard let data = data else { return}
            do {
                if let convertedJsonIntoDict = try JSONSerialization.jsonObject(with: data, options: []) as? NSDictionary {
                    if convertedJsonIntoDict["status"] as! String == "OK" {
                        completion(true)
                    }
                }
            } catch let error as NSError {
                print(error.localizedDescription)
            }
        }.resume()
    }
    
    @IBAction func eliminar(_ sender: Any) {
        if Model.indicefiltros != -1 {
            Model.removeFilter(Model.filters[Model.indicefiltros])
            eliminarServidor { (success) in
                DispatchQueue.main.async {
                    self.dismiss(animated: true, completion: nil)
                }
            }
        }
    }
    
    func eliminarServidor(_ completion:@escaping (Bool)->()){
        let nombre:String = nameTextField.text!
        let sources:String = descriptionTextView.text!
        var baseURL = URLComponents(string: "https://newsapi-victorguiochinmn.c9users.io/deleteFilter")
        baseURL?.queryItems = [URLQueryItem(name: "username", value: String(describing: Model.ID)), URLQueryItem(name: "name", value: nombre), URLQueryItem(name: "sources", value: sources)]
        let urlRequest = URLRequest(url: baseURL?.url as! URL)
        let session = URLSession.shared
        session.dataTask(with: urlRequest) {
            (data,response,error) in
            guard error == nil else { completion(false); return}
            guard let data = data else { return}
            do {
                if let convertedJsonIntoDict = try JSONSerialization.jsonObject(with: data, options: []) as? NSDictionary {
                    if convertedJsonIntoDict["status"] as! String == "OK" {
                        completion(true)
                    }
                }
            } catch let error as NSError {
                print(error.localizedDescription)
            }
            }.resume()
    }
    
    func check() {
        if Model.indicefiltros != -1 {
            updateDescription()
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        check()
    }
    
    
}
