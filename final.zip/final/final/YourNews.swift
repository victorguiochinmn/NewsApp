//
//  YourNews.swift
//  final
//
//  Created by UDLAP21 on 3/27/19.
//  Copyright © 2019 DevLabs. All rights reserved.
//

import UIKit
import WebKit

class YourNews: UIViewController {
    
    @IBOutlet weak var newsView: WKWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        loadNews(urlString: Model.filterNews[Model.indiceFiltroNoticia].urlString)
    }
    @IBAction func getBack(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func save(_ sender: Any) {
        var baseURL = URLComponents(string: "https://newsapi-victorguiochinmn.c9users.io/addArticle")
        baseURL?.queryItems = [URLQueryItem(name: "username", value: String(describing: Model.ID)), URLQueryItem(name: "title", value: Model.filterNews[Model.indiceFiltroNoticia].titulo ), URLQueryItem(name: "newspaper", value: Model.filterNews[Model.indiceFiltroNoticia].periodico), URLQueryItem(name: "url", value: Model.filterNews[Model.indiceFiltroNoticia].urlString)]
        let urlRequest = URLRequest(url: baseURL?.url as! URL)
        let session = URLSession.shared
        session.dataTask(with: urlRequest) {
            (data,response,error) in
            guard error == nil else {return}
            Model.addSaved(Model.filterNews[Model.indiceFiltroNoticia])
            }.resume()
    }
    
    func loadNews(urlString: String){
        guard let newsURL = URL(string:urlString)
            else {
                print("YAPI")
                return
        }
        newsView.load(URLRequest(url: newsURL))
    }
    
    func update(){
        newsView.reload()
        loadNews(urlString: Model.filterNews[Model.indiceFiltroNoticia].urlString)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        update()
    }
}
