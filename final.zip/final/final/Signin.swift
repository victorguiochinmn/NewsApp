//
//  Signin.swift
//  final
//
//  Created by UDLAP21 on 3/27/19.
//  Copyright © 2019 DevLabs. All rights reserved.
//

import UIKit
import SwiftyPlistManager

class Signin: UIViewController {
    var pass: Bool = false
    @IBOutlet weak var usernameTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var errorLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func register(_ sender: Any) {
        registerServer { (success) in
            DispatchQueue.main.async {
                self.check()
            }
        }
    }
    
    func registerServer(_ completion:@escaping (Bool)->()) {
        let username: String = usernameTextField.text!
        let password: String = passwordTextField.text!
        var baseURL = URLComponents(string: "https://newsapi-victorguiochinmn.c9users.io/addUser")
        baseURL?.queryItems = [URLQueryItem(name: "username", value: username), URLQueryItem(name: "password", value: password)]
        let urlRequest = URLRequest(url: baseURL?.url as! URL)
        let session = URLSession.shared
        session.dataTask(with: urlRequest) {
            (data,response,error) in
            guard error == nil else { completion(false); return}
            guard let data = data else { return}
            do {
                if let convertedJsonIntoDict = try JSONSerialization.jsonObject(with: data, options: []) as? NSDictionary {
                    if convertedJsonIntoDict["status"] as! String == "OK" {
                        let id: String = convertedJsonIntoDict["_id"] as! String
                        SwiftyPlistManager.shared.save(id, forKey: "ID", toPlistWithName: "dataPlist") { (err) in
                          if err == nil {
                            print("Value added")
                          }
                        }
                        self.pass = true
                        completion(true)
                    }
                }
            } catch let error as NSError {
                print(error.localizedDescription)
            }
        }.resume()
    }
    
    func check() {
        if pass {
            self.performSegue(withIdentifier: "sign2news", sender: self)
        } else {
            errorLabel.text = "Username already taken. Please choose another one"
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
}
