//
//  Filter.swift
//  final
//
//  Created by UDLAP21 on 5/18/19.
//  Copyright © 2019 DevLabs. All rights reserved.
//

import Foundation
class Filter: NSObject {
    var nombre : String
    var parametros : String
    
    init(unNombre: String, param: String){
        nombre = unNombre
        parametros = param
    }
}

