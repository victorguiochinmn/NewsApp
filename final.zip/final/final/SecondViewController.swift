//
//  SecondViewController.swift
//  final
//
//  Created by UDLAP21 on 2/21/19.
//  Copyright © 2019 DevLabs. All rights reserved.
//

import UIKit

class SecondViewController: UITableViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initializeView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        tableView.reloadData()
        super.viewWillAppear(true)
    }
    
    private func initializeView() {
        tableView.rowHeight = 65
        tableView.estimatedRowHeight = 65
        tableView.delegate = self
        tableView.dataSource = self
        tableView.reloadData()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        switch segue.identifier {
        case "filter2news"?:
            if let row = tableView.indexPathForSelectedRow?.row {
                Model.indicefiltros = row
            }
        default:
            preconditionFailure("Unexpected segue identifier.")
        }
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Model.filters.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell : FilterItemCell
        var item : Filter
        item = Model.filters[indexPath.row]
        cell = tableView.dequeueReusableCell(withIdentifier: "cellYourNews", for: indexPath) as! FilterItemCell
        cell.tituloLabel.text = item.nombre
        return cell
    }
}

