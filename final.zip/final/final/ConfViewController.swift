//
//  ConfViewController.swift
//  final
//
//  Created by UDLAP21 on 2/21/19.
//  Copyright © 2019 DevLabs. All rights reserved.
//

import UIKit
import SwiftyJSON

class ConfViewController: UITableViewController {
    
    override func viewDidLoad() {
        getFilters { (success) in
            DispatchQueue.main.async {
                super.viewDidLoad()
                self.initializeView()
            }
        }
    }
    
    func getFilters(_ completion:@escaping (Bool)->()){
        var baseURL = URLComponents(string: "https://newsapi-victorguiochinmn.c9users.io/filters")
        baseURL?.queryItems = [URLQueryItem(name: "username", value: String(describing: Model.ID))]
        let urlRequest = URLRequest(url: baseURL?.url as! URL)
        let session = URLSession.shared
        session.dataTask(with: urlRequest) {
            (data,response,error) in
            guard error == nil else { completion(false); return}
            guard let data = data else { return}
            let jsonResponse = JSON(data as Any)
            let filters = [Filter]()
            if let filters = jsonResponse["filters"].arrayObject as? [[String:Any]] {
                for filter in filters {
                    let newFilter = Filter(unNombre: filter["name"] as! String, param: filter["sources"] as! String)
                    Model.addFilter(newFilter)
                }
            }
            completion(true)
        }.resume()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        tableView.reloadData()
        super.viewWillAppear(true)
    }
    
    private func initializeView() {
        tableView.delegate = self
        tableView.dataSource = self
        tableView.reloadData()
        tableView.rowHeight = 65
        tableView.estimatedRowHeight = 65
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        switch segue.identifier {
        case "modify"?:
            if let row = tableView.indexPathForSelectedRow?.row {
                Model.indicefiltros = row
            }
        case "add"?:
            Model.indicefiltros = -1
        default:
            preconditionFailure("Unexpected segue identifier.")
        }
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Model.filters.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell : FilterItemCell
        var item : Filter
        item = Model.filters[indexPath.row]
        cell = tableView.dequeueReusableCell(withIdentifier: "cellFilter", for: indexPath) as! FilterItemCell
        cell.nombreLabel.text = item.nombre
        return cell
    }
}
