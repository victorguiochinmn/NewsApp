//
//  Noticia.swift
//  final
//
//  Created by UDLAP21 on 3/27/19.
//  Copyright © 2019 DevLabs. All rights reserved.
//

import Foundation
class Noticia: NSObject {
    var titulo : String
    var periodico : String
    var urlString : String
    var url : URL

    init(unTitulo: String, unaFuente: String, unaURL: String){
        titulo = unTitulo
        periodico = unaFuente
        urlString = unaURL
        url = URL(string : unaURL)!
    }
}
