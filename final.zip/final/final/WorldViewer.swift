//
//  WorldViewer.swift
//  final
//
//  Created by UDLAP21 on 3/27/19.
//  Copyright © 2019 DevLabs. All rights reserved.
//

import UIKit
import WebKit
import SwiftyPlistManager

class WorldViewer: UIViewController {
    
    @IBOutlet weak var newsView: WKWebView!
   
    @IBAction func getBack(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    @IBAction func save(_ sender: Any) {
        guardarServidor{ (success) in
            DispatchQueue.main.async {
               Model.addSaved(Model.news[Model.indiceDelActual])
            }
        }
        
    }
    
    func guardarServidor(_ completion:@escaping (Bool)->()) {
        var baseURL = URLComponents(string: "https://newsapi-victorguiochinmn.c9users.io/addArticle")
        baseURL?.queryItems = [URLQueryItem(name: "username", value: String(describing: Model.ID)), URLQueryItem(name: "title", value: Model.news[Model.indiceDelActual].titulo ), URLQueryItem(name: "newspaper", value: Model.news[Model.indiceDelActual].periodico), URLQueryItem(name: "url", value: Model.news[Model.indiceDelActual].urlString)]
        let urlRequest = URLRequest(url: baseURL?.url as! URL)
        let session = URLSession.shared
        session.dataTask(with: urlRequest) {
            (data,response,error) in
            guard error == nil else {completion(false); return}
            completion(true)
        }.resume()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        loadNews(urlString: Model.news[Model.indiceDelActual].urlString)
    }
    
    func loadNews(urlString: String){
        guard
            let newsURL = URL(string:urlString)
            else {
                return
        }
        newsView.load(URLRequest(url: newsURL))
    }
    
    func update(){
        newsView.reload()
        loadNews(urlString: Model.news[Model.indiceDelActual].urlString)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        update()
    }
}
